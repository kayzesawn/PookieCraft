MSD item pack release 1.4.2
Loot table code used and modified with permission from feucoco_da_best's MSDLT